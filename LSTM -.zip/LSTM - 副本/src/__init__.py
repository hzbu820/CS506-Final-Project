"""
LSTM Stock Price Prediction System
A comprehensive implementation of LSTM neural networks for stock price prediction
"""

__version__ = "1.0.0" 
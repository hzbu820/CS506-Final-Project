"""
Visualization module for the LSTM Stock Price Prediction System
""" 